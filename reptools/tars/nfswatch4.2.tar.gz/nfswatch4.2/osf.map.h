/*
 * HISTORY
 * $Log: osf.map.h,v $
 * Revision 1.2  1993/09/28  21:17:07  mogul
 * *** empty log message ***
 *
 * Revision 1.1  93/09/27  17:13:07  mogul
 * Initial revision
 * 
 *
 * $EndLog$
 */
/*
 * @(#)$RCSfile: osf.map.h,v $ $Revision: 1.2 $ (DEC) $Date: 1993/09/28 21:17:07 $
 */

/*
 * Cloned from ultrix.map.h, although this could really be a single
 * file.
 */

#ifndef	IPPROTO_ND
/* Trying to compile this not on a Sun system */
#define	IPPROTO_ND	77	/* From <netinet/in.h> on a Sun somewhere */
#endif	/* IPPROTO_ND */

#ifndef ETHERTYPE_REVARP
/* some systems don't define this */
#define ETHERTYPE_REVARP	0x8035
#define REVARP_REQUEST		3
#define REVARP_REPLY		4
#endif  /* ETHERTYPE_REVARP */

/* Map protocol types */
#define ETHERPUP_IPTYPE ETHERTYPE_IP
#define ETHERPUP_REVARPTYPE ETHERTYPE_REVARP
#define ETHERPUP_ARPTYPE ETHERTYPE_ARP

/* newish RIP commands */
#ifndef	RIPCMD_POLL
#define	RIPCMD_POLL	5
#endif	/* RIPCMD_POLL */
#ifndef	RIPCMD_POLLENTRY
#define	RIPCMD_POLLENTRY	6
#endif	/* RIPCMD_POLLENTRY */

from base import SecFlavor

class SecAuthNone(SecFlavor):
    pass
